# -*- coding: utf-8 -*-
"""Gap İnşaat Power BI eğitimi için KURGUSAL veri seti üretici."""
import os, json, shutil, calendar
import numpy as np, pandas as pd
from scipy.stats import beta as betad

rng = np.random.default_rng(2026)
ROOT = "/home/claude/out/GapInsaat_PowerBI_Egitim_Veriseti"
shutil.rmtree(ROOT, ignore_errors=True)
D_MASTER = f"{ROOT}/01_Ana_Veriler"; D_TX = f"{ROOT}/02_Hareketler"; D_REF = f"{ROOT}/03_Referans"
for d in [D_MASTER, f"{D_TX}/Maliyetler", D_TX, D_REF]:
    os.makedirs(d, exist_ok=True)

START = pd.Timestamp("2023-01-01"); END = pd.Timestamp("2026-09-30")
months = pd.period_range("2023-01", "2026-09", freq="M")
MI = {p: i for i, p in enumerate(months)}

# ---------------------------------------------------------------- DÖVİZ
days = pd.bdate_range(START - pd.Timedelta(days=5), END)
n = len(days)
# USD/TRY: yıllık dilimlerde drift + gürültü (sentetik)
anchors = {"2022-12-27": 18.65, "2023-06-30": 26.0, "2023-12-29": 29.5, "2024-06-28": 32.8,
           "2024-12-31": 35.3, "2025-06-30": 39.8, "2025-12-31": 43.1, "2026-09-30": 47.2}
a = pd.Series(anchors); a.index = pd.to_datetime(a.index)
base = np.interp(days.view("int64"), a.index.view("int64"), np.log(a.values))
usd = np.exp(base + np.cumsum(rng.normal(0, 0.0012, n)) * 0.3)
eurusd = 1.08 + 0.05 * np.sin(np.linspace(0, 5, n)) + np.cumsum(rng.normal(0, 0.002, n)) * 0.3
eur = usd * eurusd
fx = pd.DataFrame({"Tarih": days, "USD": usd, "EUR": eur})
fx_json = []
for r in fx.itertuples():
    for cur, mid in [("USD", r.USD), ("EUR", r.EUR)]:
        fx_json.append({"tarih": r.Tarih.strftime("%Y-%m-%d"), "doviz_kodu": cur,
                        "doviz_alis": round(mid * 0.9985, 4), "doviz_satis": round(mid * 1.0015, 4)})
with open(f"{D_REF}/Doviz_Kurlari.json", "w", encoding="utf-8") as f:
    json.dump({"kaynak": "SENTETİK - eğitim amaçlı, gerçek kur değildir", "baz_doviz": "TRY",
               "kurlar": fx_json}, f, ensure_ascii=False, indent=1)
fx_daily = fx.set_index("Tarih").reindex(pd.date_range(days[0], END)).ffill()
def rate(cur, dt):
    if cur == "TRY": return 1.0
    return fx_daily.at[dt, cur]
def usd_to(cur, usd_amt, dt):
    if cur == "USD": return usd_amt
    tr = usd_amt * fx_daily.at[dt, "USD"]
    return tr if cur == "TRY" else tr / fx_daily.at[dt, "EUR"]

# ---------------------------------------------------------------- PROJELER
proj = [
 # kod, ad, ülke, şehir, bölge, sözleşme tipi, para, başlangıç, süre(ay), bütçe USD mn, CPI, gecikme(ay)
 ("P-TR-01","Ankara Lojistik Merkezi","Türkiye","Ankara","Türkiye","Götürü Bedel","TRY","2022-10-01",30,62,1.06,3),
 ("P-TR-02","İzmir Konut Projesi Etap-2","Türkiye","İzmir","Türkiye","Birim Fiyat","TRY","2023-04-01",28,48,1.11,4),
 ("P-TR-03","İstanbul Ofis Kulesi","Türkiye","İstanbul","Türkiye","Götürü Bedel","USD","2024-02-01",34,118,0.97,0),
 ("P-TR-04","Kocaeli Endüstri Tesisi","Türkiye","Kocaeli","Türkiye","Maliyet + Kâr","EUR","2025-03-01",22,40,1.02,1),
 ("P-TM-01","Aşkabat Kongre Merkezi","Türkmenistan","Aşkabat","Orta Asya","Götürü Bedel","USD","2022-06-01",36,155,0.98,2),
 ("P-TM-02","Türkmenbaşı Liman Binaları","Türkmenistan","Türkmenbaşı","Orta Asya","Birim Fiyat","USD","2024-05-01",32,72,1.04,2),
 ("P-UZ-01","Taşkent İş Merkezi","Özbekistan","Taşkent","Orta Asya","Götürü Bedel","USD","2024-04-01",30,88,1.00,1),
 ("P-QA-01","Doha Okul Kampüsü","Katar","Doha","Orta Doğu","Götürü Bedel","USD","2023-02-01",24,95,0.95,0),
 ("P-IQ-01","Erbil Devlet Hastanesi","Irak","Erbil","Orta Doğu","Birim Fiyat","USD","2024-02-01",34,130,1.09,5),
 ("P-IQ-02","Basra Su Arıtma Tesisi","Irak","Basra","Orta Doğu","Maliyet + Kâr","USD","2025-06-01",28,66,1.01,0),
 ("P-SN-01","Dakar Spor Kompleksi","Senegal","Dakar","Afrika","Götürü Bedel","EUR","2023-01-01",26,74,1.03,2),
 ("P-GH-01","Akra Konferans Merkezi","Gana","Akra","Afrika","Götürü Bedel","USD","2025-01-01",26,58,0.99,1),
 ("P-RU-01","Kazan Konut Kompleksi","Rusya","Kazan","Rusya / BDT","Birim Fiyat","EUR","2022-09-01",30,82,1.05,2),
 ("P-RW-01","Kigali Otel ve Rezidans","Ruanda","Kigali","Afrika","Götürü Bedel","USD","2026-02-01",22,45,1.00,0),
]
cols = ["ProjeKodu","ProjeAdi","Ulke","Sehir","Bolge","SozlesmeTipi","SozlesmeParaBirimi","BaslangicTarihi",
        "PlanlananSureAy","ButceUSD_mn","CPI","GecikmeAy"]
P = pd.DataFrame(proj, columns=cols)
P["BaslangicTarihi"] = pd.to_datetime(P["BaslangicTarihi"])
P["PlanlananBitisTarihi"] = [s + pd.DateOffset(months=int(d)) - pd.Timedelta(days=1) for s, d in zip(P.BaslangicTarihi, P.PlanlananSureAy)]
P["ButceUSD"] = P.ButceUSD_mn * 1e6
P["KarMarji"] = rng.uniform(0.08, 0.17, len(P)).round(3)
first_names = ["Ahmet","Mehmet","Mustafa","Ali","Hüseyin","Hasan","İbrahim","Murat","Emre","Burak","Serkan","Kerem","Onur","Can","Tolga",
               "Ayşe","Fatma","Zeynep","Elif","Merve","Esra","Seda","Gizem","Derya","Ece","Selin","Büşra","Özge","Deniz","Cem",
               "Yusuf","Ömer","Kaan","Barış","Uğur","Volkan","Gökhan","Sinan","Erkan","Levent"]
last_names = ["Yılmaz","Kaya","Demir","Şahin","Çelik","Yıldız","Yıldırım","Öztürk","Aydın","Özdemir","Arslan","Doğan","Kılıç","Aslan",
              "Çetin","Kara","Koç","Kurt","Özkan","Şimşek","Polat","Korkmaz","Erdoğan","Güneş","Aksoy","Tekin","Bulut","Ünal","Turan","Acar"]
def fake_name(): return f"{rng.choice(first_names)} {rng.choice(last_names)}"

clients = {"P-TR-01":"Anadolu Lojistik Yatırımları A.Ş.","P-TR-02":"Ege Gayrimenkul Geliştirme A.Ş.","P-TR-03":"Boğaz Ofis Yatırım A.Ş.",
           "P-TR-04":"Marmara Sanayi Holding","P-TM-01":"Kamu İdaresi - TM Kültür Bakanlığı (kurgusal)","P-TM-02":"Kamu İdaresi - TM Liman Otoritesi (kurgusal)",
           "P-UZ-01":"Taşkent City Development LLC","P-QA-01":"Doha Education Foundation (fictional)","P-IQ-01":"Erbil Sağlık Müdürlüğü (kurgusal)",
           "P-IQ-02":"Basra Su İdaresi (kurgusal)","P-SN-01":"Dakar Sports Agency (fictional)","P-GH-01":"Accra Convention Ltd (fictional)",
           "P-RU-01":"Volga Residential Development OOO","P-RW-01":"Kigali Hospitality Group (fictional)"}
P["Musteri"] = P.ProjeKodu.map(clients)

# ---------------------------------------------------------------- PERSONEL (kurgusal)
disciplines = [("İnşaat","İnşaat Mühendisi",0.30),("Mekanik","Makine Mühendisi",0.12),("Elektrik","Elektrik Mühendisi",0.10),
               ("Planlama","Planlama Uzmanı",0.06),("Kalite","Kalite Kontrol Mühendisi",0.06),("İSG","İSG Uzmanı",0.06),
               ("Satınalma","Satınalma Uzmanı",0.08),("Finans","Şantiye Muhasebecisi",0.08),("İdari İşler","İdari İşler Sorumlusu",0.14)]
emp = []; eid = 1000
hq_ceo = eid; emp.append([eid, fake_name(), "Genel Müdürlük", "Yönetim", "Genel Müdür", None, "2010-03-01", None, "A1"]); eid += 1
regions = P.Bolge.unique()
reg_dir = {}
for rg in regions:
    reg_dir[rg] = eid; emp.append([eid, fake_name(), "Genel Müdürlük", "Yönetim", f"Bölge Direktörü - {rg}", hq_ceo, "2014-05-01", None, "A2"]); eid += 1
for i in range(30):
    d = disciplines[i % len(disciplines)]
    emp.append([eid, fake_name(), "Genel Müdürlük", d[0], f"Kıdemli {d[1]}", hq_ceo, str(pd.Timestamp("2015-01-01") + pd.Timedelta(days=int(rng.integers(0, 3000))))[:10], None, "B1"]); eid += 1
pm = {}
for r in P.itertuples():
    pm[r.ProjeKodu] = eid
    emp.append([eid, fake_name(), r.ProjeKodu, "Yönetim", "Proje Müdürü", reg_dir[r.Bolge], str(r.BaslangicTarihi - pd.Timedelta(days=60))[:10], None, "A3"]); eid += 1
    site_mgr = eid
    emp.append([eid, fake_name(), r.ProjeKodu, "İnşaat", "Şantiye Şefi", pm[r.ProjeKodu], str(r.BaslangicTarihi - pd.Timedelta(days=30))[:10], None, "B1"]); eid += 1
    size = int(18 + r.ButceUSD_mn / 3.2)
    actual_end = r.BaslangicTarihi + pd.DateOffset(months=int(r.PlanlananSureAy + r.GecikmeAy))
    dur = (actual_end - r.BaslangicTarihi).days
    for _ in range(size):
        d = disciplines[rng.choice(len(disciplines), p=[x[2] for x in disciplines])]
        s = r.BaslangicTarihi + pd.Timedelta(days=int(dur * rng.beta(1.5, 3.5)))
        e = s + pd.Timedelta(days=int(dur * rng.uniform(0.25, 0.8)))
        e = None if e > END else e
        grade = rng.choice(["B2", "C1", "C2"], p=[0.25, 0.45, 0.30])
        emp.append([eid, fake_name(), r.ProjeKodu, d[0], d[1] if grade != "C2" else d[1].replace("Mühendisi", "Teknikeri").replace("Uzmanı", "Asistanı"),
                    site_mgr, str(s)[:10], None if e is None else str(e)[:10], grade]); eid += 1
E = pd.DataFrame(emp, columns=["PersonelID","AdSoyad","AtandigiBirim","Disiplin","Unvan","YoneticiID","IseBaslamaTarihi","IstenAyrilmaTarihi","UcretKademesi"])
E["YoneticiID"] = E.YoneticiID.astype("Int64")
P["ProjeMuduruID"] = P.ProjeKodu.map(pm)

# ---------------------------------------------------------------- MALİYET KODLARI (parent-child)
cc = [("1","DİREKT MALİYETLER",None),("1.1","Malzeme","1"),("1.1.01","Hazır Beton","1.1"),("1.1.02","İnşaat Demiri","1.1"),
 ("1.1.03","Kalıp ve İskele","1.1"),("1.1.04","Agrega ve Dolgu","1.1"),("1.1.05","Çelik Konstrüksiyon","1.1"),("1.1.06","Mekanik Malzeme","1.1"),
 ("1.1.07","Elektrik Malzeme","1.1"),("1.1.08","İnce İşler Malzeme","1.1"),
 ("1.2","İşçilik","1"),("1.2.01","Kaba İnşaat İşçiliği","1.2"),("1.2.02","Mekanik İşçilik","1.2"),("1.2.03","Elektrik İşçilik","1.2"),("1.2.04","İnce İşler İşçilik","1.2"),
 ("1.3","Taşeron","1"),("1.3.01","Hafriyat Taşeronu","1.3"),("1.3.02","Cephe Taşeronu","1.3"),("1.3.03","Altyapı Taşeronu","1.3"),("1.3.04","Peyzaj Taşeronu","1.3"),
 ("1.4","Ekipman","1"),("1.4.01","Ekipman Kira","1.4"),("1.4.02","Akaryakıt","1.4"),("1.4.03","Bakım Onarım","1.4"),
 ("2","ENDİREKT MALİYETLER",None),("2.1","Şantiye Personeli","2"),("2.1.01","Teknik Personel","2.1"),("2.1.02","İdari Personel","2.1"),
 ("2.2","Şantiye Genel Giderleri","2"),("2.2.01","Kamp ve Konaklama","2.2"),("2.2.02","Yemek","2.2"),("2.2.03","Ulaşım","2.2"),
 ("2.2.04","Sigorta","2.2"),("2.2.05","Teminat Mektubu Komisyonu","2.2"),("2.2.06","İSG Giderleri","2.2"),
 ("3","GENEL MÜDÜRLÜK GİDER PAYI",None),("3.1","GM Payı","3"),("3.1.01","GM Gider Dağıtımı","3.1")]
CC = pd.DataFrame(cc, columns=["MaliyetKodu","MaliyetKoduAdi","UstMaliyetKodu"])
CC["Seviye"] = CC.MaliyetKodu.str.count(r"\.") + 1
CC["DetayKodMu"] = np.where(CC.Seviye == 3, "Evet", "Hayır")
leaf = CC[CC.Seviye == 3].MaliyetKodu.tolist()
# faz ağırlıkları: (erken, orta, geç)
phase_w = {"1.1.01":(8,10,2),"1.1.02":(7,8,1),"1.1.03":(4,4,1),"1.1.04":(4,2,1),"1.1.05":(1,5,2),"1.1.06":(0.3,3,5),"1.1.07":(0.3,3,5),
 "1.1.08":(0.1,1,7),"1.2.01":(7,7,2),"1.2.02":(0.3,2,4),"1.2.03":(0.3,2,4),"1.2.04":(0.1,1,6),"1.3.01":(7,1,0.2),"1.3.02":(0.2,3,4),
 "1.3.03":(3,2,2),"1.3.04":(0.1,0.3,3),"1.4.01":(3,3,1.5),"1.4.02":(1.5,1.5,0.7),"1.4.03":(0.7,0.7,0.4),"2.1.01":(3,3,3),
 "2.1.02":(1.5,1.5,1.5),"2.2.01":(2,2,2),"2.2.02":(1.2,1.2,1.2),"2.2.03":(0.8,0.8,0.8),"2.2.04":(0.6,0.6,0.6),"2.2.05":(0.4,0.4,0.4),
 "2.2.06":(0.5,0.5,0.5),"3.1.01":(2,2,2)}
def cc_weights(frac):
    w = np.array([np.interp(frac, [0, 0.5, 1], phase_w[c]) for c in leaf]) + 1e-6
    return w / w.sum()

# ---------------------------------------------------------------- İLERLEME + BÜTÇE + MALİYET HEDEFİ
prog_rows, bud_rows, mcost = [], [], {}
for r in P.itertuples():
    s = pd.Period(r.BaslangicTarihi, "M"); Dp = r.PlanlananSureAy; Da = Dp + r.GecikmeAy
    for m in months:
        k = (m - s).n + 1  # proje ayı (1..)
        if k < 1: continue
        plan = betad.cdf(min(k / Dp, 1), 2.2, 2.4)
        act = betad.cdf(min(max(k - 0.6, 0) / Da, 1), 2.4, 2.4)
        prev_plan = betad.cdf(min(max(k - 1, 0) / Dp, 1), 2.2, 2.4)
        prev_act = betad.cdf(min(max(k - 1.6, 0) / Da, 1), 2.4, 2.4) if k > 1 else 0
        if prev_act >= 0.9999 and prev_plan >= 0.9999: continue
        prog_rows.append([r.ProjeKodu, m.end_time.normalize().date(), round(plan * 100, 2), round(act * 100, 2)])
        # bütçe (orijinal + R1)
        dplan = plan - prev_plan
        if dplan > 1e-6:
            w = cc_weights(min(k / Dp, 1))
            for c, wi in zip(leaf, w):
                bud_rows.append([r.ProjeKodu, c, m, "Orijinal", r.ButceUSD * dplan * wi])
        # revize bütçe: 2025'ten itibaren kalan işi CPI'ın yarısı kadar artırır ve gerçekleşen eğriye göre yayar
        dact = act - prev_act
        if dact > 1e-6:
            w = cc_weights(min(k / Da, 1))
            mcost[(r.ProjeKodu, m)] = (r.ButceUSD * dact * r.CPI * rng.normal(1, 0.06), w)
            for c, wi in zip(leaf, w):
                bud_rows.append([r.ProjeKodu, c, m, "Revize-1", r.ButceUSD * dact * (1 + (r.CPI - 1) * 0.6) * wi])
PR = pd.DataFrame(prog_rows, columns=["ProjeKodu","DonemSonu","PlanlananKumulatifIlerlemeYuzde","GerceklesenKumulatifIlerlemeYuzde"])

# Bütçe: GENİŞ format, başlıkta rapor satırları (Unpivot / Promote headers alıştırması)
B = pd.DataFrame(bud_rows, columns=["ProjeKodu","MaliyetKodu","Donem","Versiyon","Tutar"])
B["Tutar"] = B.Tutar.round(0)
tr_mon = ["Oca","Şub","Mar","Nis","May","Haz","Tem","Ağu","Eyl","Eki","Kas","Ara"]
B["Kol"] = B.Donem.map(lambda p: f"{tr_mon[p.month-1]}.{str(p.year)[2:]}")
order = [f"{tr_mon[p.month-1]}.{str(p.year)[2:]}" for p in months]
BW = B.pivot_table(index=["Versiyon","ProjeKodu","MaliyetKodu"], columns="Kol", values="Tutar", aggfunc="sum").reindex(columns=order).reset_index()
BW.insert(3, "ParaBirimi", "USD")
with pd.ExcelWriter(f"{D_TX}/Butce_2023_2026.xlsx", engine="openpyxl") as xw:
    for ver in ["Orijinal", "Revize-1"]:
        part = BW[BW.Versiyon == ver].drop(columns="Versiyon")
        part.to_excel(xw, sheet_name=f"Bütçe {ver}", index=False, startrow=3)
        ws = xw.sheets[f"Bütçe {ver}"]
        ws["A1"] = f"GAP İNŞAAT - PROJE BÜTÇELERİ ({ver.upper()} VERSİYON) - KURGUSAL EĞİTİM VERİSİ"
        ws["A2"] = "Rapor tarihi: 15.10.2026   |   Tutarlar USD   |   Kaynak: Planlama Müdürlüğü"
    # toplam satırı (filtrelenmesi gereken tuzak)
    for ver in ["Orijinal", "Revize-1"]:
        ws = xw.sheets[f"Bütçe {ver}"]
        last = ws.max_row + 1
        ws.cell(row=last, column=1, value="GENEL TOPLAM")

# ---------------------------------------------------------------- TEDARİKÇİLER (kirli)
sup_base = [("Anadolu Hazır Beton A.Ş.","Türkiye","Hazır Beton"),("Kuzey Demir Çelik San. A.Ş.","Türkiye","İnşaat Demiri"),
 ("Akdeniz Kalıp İskele Ltd. Şti.","Türkiye","Kalıp ve İskele"),("Ege Agrega Madencilik A.Ş.","Türkiye","Agrega"),
 ("Marmara Çelik Konstrüksiyon A.Ş.","Türkiye","Çelik Konstrüksiyon"),("Delta Mekanik Sistemler A.Ş.","Türkiye","Mekanik"),
 ("Volt Elektrik Malzemeleri Ltd. Şti.","Türkiye","Elektrik"),("Seramik Dünyası Yapı Market A.Ş.","Türkiye","İnce İşler"),
 ("Hafriyatçı Kardeşler İnş. Ltd. Şti.","Türkiye","Hafriyat"),("Cam Cephe Sistemleri A.Ş.","Türkiye","Cephe"),
 ("Altyapı Proje Taahhüt A.Ş.","Türkiye","Altyapı"),("Yeşil Peyzaj Ltd. Şti.","Türkiye","Peyzaj"),
 ("İş Makinesi Kiralama A.Ş.","Türkiye","Ekipman Kira"),("Petrol Ofisi Bayi - Kurgusal Akaryakıt","Türkiye","Akaryakıt"),
 ("Caspian Building Supplies LLC","Türkmenistan","Hazır Beton"),("Ashgabat Steel Trading","Türkmenistan","İnşaat Demiri"),
 ("Gulf Ready Mix WLL","Katar","Hazır Beton"),("Doha MEP Contracting","Katar","Mekanik"),("Erbil Construction Materials Co.","Irak","Agrega"),
 ("Basra Heavy Equipment Rental","Irak","Ekipman Kira"),("Dakar Matériaux SARL","Senegal","İnce İşler"),("Sahel Logistique SA","Senegal","Ulaşım"),
 ("Accra Cement & Blocks Ltd","Gana","Hazır Beton"),("Volga Stroy OOO","Rusya","Taşeron"),("Kazan Metall OOO","Rusya","İnşaat Demiri"),
 ("Tashkent Glass Facade LLC","Özbekistan","Cephe"),("Kigali Build Supplies Ltd","Ruanda","İnce İşler"),
 ("Euro Elevator Systems GmbH","Almanya","Mekanik"),("Siemens-Benzeri Otomasyon GmbH (kurgusal)","Almanya","Elektrik"),
 ("Global Camp Services FZE","BAE","Kamp ve Konaklama"),("Catering Plus FZE","BAE","Yemek"),("Atlas Sigorta A.Ş. (kurgusal)","Türkiye","Sigorta"),
 ("Kurgu Bank A.Ş.","Türkiye","Teminat Komisyonu"),("Güvenli İş İSG Danışmanlık","Türkiye","İSG"),("Mavi Taşımacılık Ltd. Şti.","Türkiye","Ulaşım"),
]
S = []
for i, (nm, c, cat) in enumerate(sup_base):
    S.append([f"T{2001+i}", nm, c, cat, str(rng.integers(1000000000, 9999999999)) if c == "Türkiye" else "", rng.choice([30, 45, 60, 90])])
# kasıtlı mükerrer / tutarsız kayıtlar
dups = [(0, "ANADOLU HAZIR BETON A.Ş. "), (1, "Kuzey Demir Celik San. AŞ"), (5, "delta mekanik sistemler a.ş."), (16, "Gulf Ready-Mix W.L.L.")]
for j, (src, nm) in enumerate(dups):
    S.append([f"T{2101+j}", nm, S[src][2] if j != 2 else " türkiye", S[src][3], S[src][4], S[src][5]])
SUP = pd.DataFrame(S, columns=["TedarikciID","TedarikciUnvani","Ulke","AnaKategori","VergiNo","OdemeVadesiGun"])
SUP.loc[SUP.sample(3, random_state=1).index, "Ulke"] = None
SUP.to_csv(f"{D_MASTER}/Tedarikciler.csv", sep=";", index=False, encoding="utf-8-sig")
cat_sup = {}
for r in SUP.itertuples(): cat_sup.setdefault(r.AnaKategori, []).append(r.TedarikciID)
cc_cat = {"1.1.01":"Hazır Beton","1.1.02":"İnşaat Demiri","1.1.03":"Kalıp ve İskele","1.1.04":"Agrega","1.1.05":"Çelik Konstrüksiyon",
          "1.1.06":"Mekanik","1.1.07":"Elektrik","1.1.08":"İnce İşler","1.3.01":"Hafriyat","1.3.02":"Cephe","1.3.03":"Altyapı","1.3.04":"Peyzaj",
          "1.4.01":"Ekipman Kira","1.4.02":"Akaryakıt","2.2.01":"Kamp ve Konaklama","2.2.02":"Yemek","2.2.03":"Ulaşım","2.2.04":"Sigorta",
          "2.2.05":"Teminat Komisyonu","2.2.06":"İSG","1.2.01":"Taşeron","1.4.03":"Ekipman Kira"}

# ---------------------------------------------------------------- MALİYET HAREKETLERİ (klasör, aylık CSV)
desc = {"1.1.01":"C30 hazır beton sevkiyatı","1.1.02":"Ø12-Ø32 nervürlü demir","1.1.03":"Kalıp/iskele kira ve alım","1.1.04":"Agrega/dolgu malzemesi",
 "1.1.05":"Çelik konstrüksiyon imalat","1.1.06":"HVAC / sıhhi tesisat malzemesi","1.1.07":"Kablo, pano, aydınlatma","1.1.08":"Seramik, alçı, boya",
 "1.2.01":"Kaba inşaat işçilik hakedişi","1.2.02":"Mekanik montaj işçiliği","1.2.03":"Elektrik montaj işçiliği","1.2.04":"İnce işler işçiliği",
 "1.3.01":"Hafriyat taşeron hakedişi","1.3.02":"Cephe taşeron hakedişi","1.3.03":"Altyapı taşeron hakedişi","1.3.04":"Peyzaj taşeron hakedişi",
 "1.4.01":"İş makinesi kira bedeli","1.4.02":"Motorin alımı","1.4.03":"Ekipman bakım onarım","2.1.01":"Teknik personel ücret tahakkuku",
 "2.1.02":"İdari personel ücret tahakkuku","2.2.01":"Kamp konaklama gideri","2.2.02":"Yemek hizmeti","2.2.03":"Personel servis/ulaşım",
 "2.2.04":"İnşaat all-risk sigorta primi","2.2.05":"Teminat mektubu komisyonu","2.2.06":"KKD ve İSG malzemesi","3.1.01":"GM gider dağıtımı"}
no_sup = {"2.1.01","2.1.02","3.1.01"}
all_tx = []; belge = 500000
for (pk, m), (tot, w) in sorted(mcost.items(), key=lambda x: (x[0][1], x[0][0])):
    if m > months[-1]: continue
    country = P.set_index("ProjeKodu").at[pk, "Ulke"]
    nlines = int(np.clip(tot / 11000, 80, 900))
    cc_pick = rng.choice(len(leaf), size=nlines, p=w)
    amt = rng.dirichlet(np.ones(nlines) * 0.8) * tot
    mdays = pd.date_range(m.start_time, m.end_time)
    for c_i, a in zip(cc_pick, amt):
        c = leaf[c_i]
        dt = mdays[rng.integers(0, len(mdays))]
        if c in no_sup | {"2.2.04", "2.2.05"} or (country == "Türkiye"):
            cur = "TRY" if country == "Türkiye" or c in no_sup else rng.choice(["USD", "EUR"])
        else:
            cur = rng.choice(["USD", "EUR", "TRY"], p=[0.7, 0.2, 0.1])
        if c in ("2.1.01", "2.1.02", "3.1.01"): cur = "TRY" if country == "Türkiye" else "USD"
        sup = "" if c in no_sup else rng.choice(cat_sup.get(cc_cat.get(c, ""), SUP.TedarikciID.tolist()[:14]))
        sign = -1 if rng.random() < 0.015 else 1  # iade / alacak dekontu
        belge += 1
        all_tx.append([f"MB{belge}", dt, dt + pd.Timedelta(days=int(rng.integers(0, 9))), pk, c, sup,
                       desc[c] + (" - İADE" if sign < 0 else ""), round(sign * usd_to(cur, a, dt), 2), cur])
TX = pd.DataFrame(all_tx, columns=["BelgeNo","BelgeTarihi","KayitTarihi","ProjeKodu","MaliyetKodu","TedarikciID","Aciklama","Tutar","ParaBirimi"])
# kirlilik: proje kodu tutarsızlığı, boş maliyet kodu, mükerrer satırlar
idx = TX.sample(frac=0.01, random_state=3).index; TX.loc[idx, "ProjeKodu"] = TX.loc[idx, "ProjeKodu"].str.lower()
idx = TX.sample(frac=0.006, random_state=4).index; TX.loc[idx, "ProjeKodu"] = TX.loc[idx, "ProjeKodu"] + "  "
idx = TX.sample(n=60, random_state=5).index; TX.loc[idx, "MaliyetKodu"] = ""
TX = pd.concat([TX, TX.sample(n=150, random_state=6)]).sort_values(["BelgeTarihi", "BelgeNo"])
def fmt_num(x): return f"{x:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
TX["Ay"] = TX.KayitTarihi.dt.to_period("M").clip(upper=months[-1])
for m, g in TX.groupby("Ay"):
    g = g.drop(columns="Ay").copy()
    if m < pd.Period("2025-01", "M"):  # eski ERP formatı
        g["BelgeTarihi"] = g.BelgeTarihi.dt.strftime("%d.%m.%Y"); g["KayitTarihi"] = g.KayitTarihi.dt.strftime("%d.%m.%Y")
        g["Tutar"] = g.Tutar.map(fmt_num)
    else:  # yeni ERP: kolon adları değişti, yeni kolon eklendi, ISO tarih
        g["BelgeTarihi"] = g.BelgeTarihi.dt.strftime("%Y-%m-%d"); g["KayitTarihi"] = g.KayitTarihi.dt.strftime("%Y-%m-%d")
        g["Tutar"] = g.Tutar.map(fmt_num)
        g = g.rename(columns={"Tutar": "BelgeTutari", "ParaBirimi": "BelgeParaBirimi"})
        g["KaydedenKullanici"] = rng.choice(["muh.ayse", "muh.can", "muh.selin", "muh.burak", "entegrasyon"], len(g))
    g.to_csv(f"{D_TX}/Maliyetler/Maliyet_{m.year}_{m.month:02d}.csv", sep=";", index=False, encoding="utf-8-sig")
shutil.copy(f"{D_TX}/Maliyetler/Maliyet_2024_07.csv", f"{D_TX}/Maliyetler/Maliyet_2024_07 - Kopya.csv")  # tuzak
with open(f"{D_TX}/Maliyetler/Okubeni.txt", "w", encoding="utf-8") as f:
    f.write("Bu klasöre ERP'den her ay maliyet dökümü atılır. 2025 Ocak itibarıyla yeni ERP'ye geçildi.\n")

# ---------------------------------------------------------------- HAKEDİŞLER
hk = []; tx_us = {}
for (pk, m), (tot, w) in mcost.items(): tx_us[(pk, m)] = tot
Pi = P.set_index("ProjeKodu")
for pk in P.ProjeKodu:
    r = Pi.loc[pk]; cur = r.SozlesmeParaBirimi
    start_dt = r.BaslangicTarihi
    contract_usd = r.ButceUSD * (1 + r.KarMarji)
    contract_val = usd_to(cur, contract_usd, max(start_dt, fx_daily.index[0]))
    pr = PR[PR.ProjeKodu == pk].reset_index(drop=True)
    prev = 0; no = 0
    for i, row in pr.iterrows():
        cum = row.GerceklesenKumulatifIlerlemeYuzde / 100
        d = cum - prev
        if d < 0.002: continue
        no += 1; prev = cum
        per_end = pd.Timestamp(row.DonemSonu)
        brut = contract_val * d
        ff = brut * max(0, (fx_daily.at[per_end, "USD"] / fx_daily.at[max(start_dt, fx_daily.index[0]), "USD"] - 1)) * 0.55 if cur == "TRY" else 0
        avans = brut * 0.10 if cum < 0.85 else 0
        teminat = (brut + ff) * 0.05
        kdv = (brut + ff) * 0.20 if Pi.at[pk, "Ulke"] == "Türkiye" else 0
        net = brut + ff - avans - teminat + kdv
        fat = per_end + pd.Timedelta(days=int(rng.integers(8, 25)))
        tah = fat + pd.Timedelta(days=int(rng.gamma(4, 14 if r.Bolge in ("Afrika", "Orta Doğu") else 9)))
        tah_t = tah if tah <= END else pd.NaT
        hk.append([f"{pk} - {r.ProjeAdi}", no, per_end.strftime("%Y-%m"), round(brut, 2), round(ff, 2), round(avans, 2),
                   round(teminat, 2), round(kdv, 2), round(net, 2), cur, fat.date(), tah_t.date() if pd.notna(tah_t) else None,
                   "Tahsil Edildi" if pd.notna(tah_t) else "Açık"])
HK = pd.DataFrame(hk, columns=["Proje","HakedisNo","Donem","BrutHakedisTutari","FiyatFarki","AvansMahsubu","TeminatKesintisi",
                               "KDV","NetOdenecek","ParaBirimi","FaturaTarihi","TahsilatTarihi","Durum"])
HK.to_excel(f"{D_TX}/Hakedisler.xlsx", sheet_name="Hakedişler", index=False)

# ---------------------------------------------------------------- MALZEMELER + SATINALMA
mats = []
mdef = [("Hazır Beton","m³",["C25/30","C30/37","C35/45","C40/50"],95,"1.1.01"),("İnşaat Demiri","ton",["Ø8","Ø12","Ø16","Ø20","Ø25","Ø32"],720,"1.1.02"),
 ("Kalıp ve İskele","m²",["Plywood kalıp","Tünel kalıp","Cephe iskelesi"],28,"1.1.03"),("Agrega","ton",["0-5 kum","5-15 mıcır","15-25 mıcır","Stabilize"],14,"1.1.04"),
 ("Çelik Konstrüksiyon","ton",["HEA profil","IPE profil","Trapez sac"],1450,"1.1.05"),("Mekanik","adet",["Klima santrali","Fan coil","Pompa grubu","Yangın sprinkler seti","PPRC boru (100m)"],2100,"1.1.06"),
 ("Elektrik","adet",["Ana dağıtım panosu","NYY kablo (100m)","LED armatür","Jeneratör 500kVA","Trafo 1600kVA"],1800,"1.1.07"),
 ("İnce İşler","m²",["Granit seramik","Alçıpan","İç cephe boyası","Laminat parke","Asma tavan"],22,"1.1.08")]
mid = 1
for cat, unit, items, price, c in mdef:
    for it in items:
        mats.append([f"M{mid:04d}", f"{it}", cat, unit, round(price * rng.uniform(0.5, 1.8), 2), c]); mid += 1
M = pd.DataFrame(mats, columns=["MalzemeKodu","MalzemeAdi","MalzemeGrubu","OlcuBirimi","StandartBirimFiyatUSD","MaliyetKodu"])
M.to_excel(f"{D_MASTER}/Malzemeler.xlsx", index=False, sheet_name="Malzemeler")
cat_to_sup = {k: v for k, v in cat_sup.items()}
po = []; pono = 45000000
proj_staff = E[E.Disiplin.isin(["Satınalma", "İnşaat", "Mekanik", "Elektrik"])].groupby("AtandigiBirim").PersonelID.apply(list).to_dict()
buyers = E[E.Disiplin == "Satınalma"].groupby("AtandigiBirim").PersonelID.apply(list).to_dict()
for (pk, m), (tot, w) in mcost.items():
    if m > months[-1]: continue
    nord = int(np.clip(tot / 400000, 2, 12))
    for _ in range(nord):
        pono += 1
        od = m.start_time + pd.Timedelta(days=int(rng.integers(0, 27)))
        sup_cat = rng.choice(list(set(M.MalzemeGrubu)))
        sid = rng.choice(cat_to_sup.get(sup_cat, ["T2001"]))
        cur = "TRY" if Pi.at[pk, "Ulke"] == "Türkiye" and rng.random() < 0.8 else rng.choice(["USD", "EUR"], p=[0.75, 0.25])
        req = rng.choice(proj_staff.get(pk, [pm[pk]]))
        appr = pm[pk] if rng.random() > 0.015 else req  # SoD ihlali
        if rng.random() < 0.02: appr = rng.choice(buyers.get(pk, [pm[pk]]))
        lead = int(rng.gamma(3, 8 if Pi.at[pk, "Ulke"] == "Türkiye" else 14))
        promise = od + pd.Timedelta(days=lead)
        mm = M[M.MalzemeGrubu == sup_cat]
        for ln in range(1, int(rng.integers(1, 6)) + 1):
            mt = mm.sample(1, random_state=int(rng.integers(0, 1e9))).iloc[0]
            qty = round(float(rng.gamma(2, 50 if mt.OlcuBirimi in ("m³", "m²") else 8 if mt.OlcuBirimi == "ton" else 4)), 1) + 1
            up_usd = mt.StandartBirimFiyatUSD * rng.normal(1, 0.08)
            up = usd_to(cur, up_usd, od)
            delay = int(rng.choice([0, 0, 0, 2, 5, 10, 21, 45], p=[0.35, 0.15, 0.1, 0.12, 0.1, 0.09, 0.06, 0.03]))
            deliv = promise + pd.Timedelta(days=delay - int(rng.integers(0, 4)))
            if deliv > END:
                dq, dd, st = 0, None, "Açık"
            else:
                dq = qty if rng.random() > 0.05 else round(qty * rng.uniform(0.5, 0.95), 1)
                dd, st = deliv.date(), ("Tamamlandı" if dq == qty else "Kısmi Teslim")
            po.append([f"PO{pono}", ln, od.date(), pk, sid, mt.MalzemeKodu, qty, mt.OlcuBirimi, round(up, 2), cur,
                       promise.date(), dd, dq, st, int(req), int(appr)])
PO = pd.DataFrame(po, columns=["SiparisNo","SatirNo","SiparisTarihi","ProjeKodu","TedarikciID","MalzemeKodu","SiparisMiktari","Birim",
                               "BirimFiyat","ParaBirimi","TaahhutTeslimTarihi","GerceklesenTeslimTarihi","TeslimAlinanMiktar","Durum",
                               "TalepEdenPersonelID","OnaylayanPersonelID"])
PO.to_excel(f"{D_TX}/Satinalma_Siparisleri.xlsx", index=False, sheet_name="Siparişler")

# ---------------------------------------------------------------- PUANTAJ (proje başına sayfa, geniş format)
holidays = {"01-01","04-23","05-01","05-19","07-15","08-30","10-29"}
mh_rows = []
with pd.ExcelWriter(f"{D_TX}/Puantaj.xlsx", engine="openpyxl") as xw:
    for pk in P.ProjeKodu:
        staff = E[E.AtandigiBirim == pk]
        rows = []
        for e in staff.itertuples():
            s = pd.Timestamp(e.IseBaslamaTarihi); en = pd.Timestamp(e.IstenAyrilmaTarihi) if e.IstenAyrilmaTarihi else END
            for m in months:
                if m.end_time < s or m.start_time > en: continue
                vals = []
                for d in range(1, 32):
                    if d > m.days_in_month: vals.append(None); continue
                    dt = pd.Timestamp(m.year, m.month, d)
                    if dt < s or dt > en: vals.append(None); continue
                    if dt.weekday() == 6 or f"{m.month:02d}-{d:02d}" in holidays: vals.append("H"); continue
                    u = rng.random()
                    if u < 0.03: vals.append("İ")
                    elif u < 0.04: vals.append("R")
                    elif u < 0.042: vals.append("Mz")
                    else: vals.append(int(rng.choice([8, 9, 10, 11], p=[0.45, 0.25, 0.2, 0.1])) if dt.weekday() < 5 else int(rng.choice([4, 8])))
                rows.append([e.PersonelID, e.AdSoyad, m.year, m.month] + vals)
                mh_rows.append([pk, m, sum(v for v in vals if isinstance(v, int))])
        df = pd.DataFrame(rows, columns=["Sicil No","Ad Soyad","Yıl","Ay"] + [str(i) for i in range(1, 32)])
        df.to_excel(xw, sheet_name=pk, index=False)
    pd.DataFrame({"Kısaltma":["sayı","H","İ","R","Mz","boş"],"Anlamı":["Çalışılan saat","Hafta tatili / resmi tatil","Yıllık izin",
                  "Sağlık raporu","Mazeret izni","Kadroda değil / ay dışı gün"]}).to_excel(xw, sheet_name="Açıklama", index=False)
MH = pd.DataFrame(mh_rows, columns=["ProjeKodu","Ay","Saat"]).groupby(["ProjeKodu","Ay"]).Saat.sum()
# taşeron işçileri dahil toplam adam-saat çarpanı (İSG oranları için)
# ---------------------------------------------------------------- İSG OLAYLARI
isg = []; ino = 1
types = [("Ramak Kala", 0.62, 0), ("İlk Yardım Vakası", 0.25, 0), ("Tıbbi Müdahale Gerektiren", 0.08, 0), ("Kayıp Günlü Kaza", 0.05, 1)]
causes = ["Yüksekten düşme","Malzeme düşmesi","Elektrik çarpması","İş makinesi teması","Kayma / takılma","El aleti yaralanması","Kimyasal maruziyet","Sıcak stresi"]
total_mh = {}
for (pk, m), h in MH.items():
    tot_mh = h * rng.uniform(5.5, 7.5)  # taşeron dahil toplam adam-saat
    total_mh[(pk, m)] = round(tot_mh)
    lam = tot_mh / 200000 * 6
    for _ in range(rng.poisson(lam)):
        t = types[rng.choice(4, p=[x[1] for x in types])]
        dt = m.start_time + pd.Timedelta(days=int(rng.integers(0, m.days_in_month)))
        lost = int(rng.gamma(2, 6)) + 1 if t[2] else 0
        isg.append([f"ISG-{ino:05d}", dt.date(), f"{rng.integers(7,19):02d}:{rng.integers(0,60):02d}", pk, t[0], rng.choice(causes), lost,
                    rng.choice(["Ana Yüklenici", "Taşeron"], p=[0.35, 0.65]), rng.choice(["Kapalı", "Kapalı", "Kapalı", "Açık"])]); ino += 1
ISG = pd.DataFrame(isg, columns=["OlayNo","OlayTarihi","OlaySaati","ProjeKodu","OlayTipi","OlayNedeni","KayipGunSayisi","Calisan Tipi","DOF Durumu"])
with pd.ExcelWriter(f"{D_TX}/ISG.xlsx", engine="openpyxl") as xw:
    ISG.to_excel(xw, sheet_name="Olaylar", index=False)
    AH = pd.DataFrame([[k[0], k[1].end_time.date(), v] for k, v in total_mh.items()], columns=["ProjeKodu","DonemSonu","ToplamAdamSaat"])
    AH.to_excel(xw, sheet_name="Adam_Saat", index=False)

# ---------------------------------------------------------------- EKİPMAN
eq_types = [("Ekskavatör", 165, 18), ("Kule Vinç", 0, 9), ("Mobil Vinç", 210, 6), ("Beton Pompası", 120, 7), ("Kamyon", 95, 22),
            ("Loder", 140, 8), ("Silindir", 80, 5), ("Jeneratör", 60, 10), ("Forklift", 40, 6)]
eqs = []; ekid = 1
brands = ["Marka A", "Marka B", "Marka C", "Marka D"]
for t, rate_h, cnt in eq_types:
    for _ in range(cnt):
        eqs.append([f"EK-{ekid:03d}", t, rng.choice(brands), int(rng.integers(2014, 2025)), rng.choice(["Özmal", "Kiralık"], p=[0.6, 0.4]),
                    round(rate_h * rng.uniform(0.8, 1.2), 1) if rate_h else 0, round(rng.uniform(8, 32), 1) if t not in ("Kule Vinç",) else 0]); ekid += 1
EQ = pd.DataFrame(eqs, columns=["EkipmanKodu","EkipmanTipi","Marka","ModelYili","Mulkiyet","SaatlikMaliyetUSD","SaatlikYakitLitre"])
EQ.loc[EQ.EkipmanTipi == "Kule Vinç", "SaatlikMaliyetUSD"] = 0  # elektrikli, kira aylık
EQ.to_excel(f"{D_MASTER}/Ekipmanlar.xlsx", index=False, sheet_name="Ekipmanlar")
use = []
active = [(r.ProjeKodu, r.BaslangicTarihi, r.BaslangicTarihi + pd.DateOffset(months=int(r.PlanlananSureAy + r.GecikmeAy))) for r in P.itertuples()]
for e in EQ.itertuples():
    t = START
    while t < END:
        cands = [a for a in active if a[1] <= t + pd.Timedelta(days=30) and a[2] > t]
        if not cands: t += pd.Timedelta(days=30); continue
        pk, s, en = cands[rng.integers(0, len(cands))]
        stay_end = min(en, END, t + pd.Timedelta(days=int(rng.integers(90, 420))))
        for dt in pd.date_range(max(t, s), stay_end):
            if dt.weekday() == 6: continue
            if rng.random() < 0.06:
                use.append([dt.date(), e.EkipmanKodu, pk, 0.0, 0.0, "Arıza"]); continue
            h = round(float(np.clip(rng.normal(8.5 if dt.weekday() < 5 else 5, 2), 0, 12)), 1)
            use.append([dt.date(), e.EkipmanKodu, pk, h, round(h * e.SaatlikYakitLitre * rng.normal(1, 0.1), 1), "Çalıştı" if h > 0 else "Boşta"])
        t = stay_end + pd.Timedelta(days=int(rng.integers(5, 30)))
EU = pd.DataFrame(use, columns=["Tarih","EkipmanKodu","ProjeKodu","CalismaSaati","YakitLitre","Durum"])
EU["CalismaSaati"] = EU.CalismaSaati.map(lambda x: f"{x:.1f}".replace(".", ","))
EU["YakitLitre"] = EU.YakitLitre.map(lambda x: f"{x:.1f}".replace(".", ","))
EU.to_csv(f"{D_TX}/Ekipman_Kullanim.csv", sep=";", index=False, encoding="utf-8-sig")

# ---------------------------------------------------------------- PROJELER (kirli) + MÜŞTERİ + PERSONEL yazımı
Pout = P[["ProjeKodu","ProjeAdi","Musteri","Ulke","Sehir","Bolge","SozlesmeTipi","SozlesmeParaBirimi","BaslangicTarihi","PlanlananBitisTarihi","ProjeMuduruID"]].copy()
Pout["SozlesmeBedeli"] = [round(usd_to(r.SozlesmeParaBirimi, r.ButceUSD * (1 + r.KarMarji), max(r.BaslangicTarihi, fx_daily.index[0])), -3) for r in P.itertuples()]
Pout["OnaylıButceUSD"] = P.ButceUSD
Pout["Durum"] = ["Tamamlandı" if (s + pd.DateOffset(months=int(d + g))) < END else ("Başlamadı" if s > END else "Devam Ediyor")
                 for s, d, g in zip(P.BaslangicTarihi, P.PlanlananSureAy, P.GecikmeAy)]
Pout.loc[2, "Ulke"] = "türkiye "; Pout.loc[9, "Ulke"] = "IRAK"; Pout.loc[5, "Sehir"] = " Türkmenbaşı"
Pout["BaslangicTarihi"] = Pout.BaslangicTarihi.dt.date; Pout["PlanlananBitisTarihi"] = Pout.PlanlananBitisTarihi.dt.date
Pout.to_excel(f"{D_MASTER}/Projeler.xlsx", index=False, sheet_name="Projeler")
CC.to_excel(f"{D_MASTER}/Maliyet_Kodlari.xlsx", index=False, sheet_name="MaliyetKodlari")
E.to_excel(f"{D_MASTER}/Personel.xlsx", index=False, sheet_name="Personel")
PR.to_excel(f"{D_TX}/Proje_Ilerleme.xlsx", index=False, sheet_name="Ilerleme")

# ---------------------------------------------------------------- REFERANS: RLS + Hedefler
rls = [["genel.mudur@ornek-egitim.com", "TÜMÜ"]] + [[f"direktor.{i+1}@ornek-egitim.com", rg] for i, rg in enumerate(regions)] + \
      [["finans.analist@ornek-egitim.com", "TÜMÜ"], ["denetim@ornek-egitim.com", "TÜMÜ"]]
pd.DataFrame(rls, columns=["KullaniciEposta","Bolge"]).to_excel(f"{D_REF}/RLS_Kullanici_Bolge.xlsx", index=False)
pd.DataFrame([[rg, y, round(rng.uniform(0.08, 0.14), 3), round(rng.uniform(0.95, 1.0), 2), round(rng.uniform(0.3, 0.6), 2), 60 if rg in ("Afrika","Orta Doğu") else 45]
              for rg in regions for y in (2023, 2024, 2025, 2026)],
             columns=["Bolge","Yil","HedefBrutKarMarji","HedefCPI","HedefLTIFR","HedefDSOGun"]).to_csv(f"{D_REF}/Bolge_Hedefleri.csv", sep=";", index=False, encoding="utf-8-sig", decimal=",")

# istatistik
stats = {}
for root, _, files in os.walk(ROOT):
    for fn in files: stats[os.path.relpath(os.path.join(root, fn), ROOT)] = os.path.getsize(os.path.join(root, fn))
print(len(TX), "maliyet satırı;", len(PO), "PO satırı;", len(EU), "ekipman satırı;", len(ISG), "İSG;", len(HK), "hakediş;", len(E), "personel")
print(Pout[["ProjeKodu","Durum","SozlesmeParaBirimi","SozlesmeBedeli"]])
print(sum(stats.values()) / 1e6, "MB toplam,", len(stats), "dosya")
